import React from 'react';

class AdminWindow extends React.Component {
    render() {
        return (
            <main>
                <h1>Administrators</h1>
                <h2>Access and edit all data here.</h2>
            </main>
        );
    }
    
}


export default AdminWindow;