import React from 'react';
import './Message.css';

function Message() {
    
    return (
      <div id="message">
        
      </div>
    );
}
  
export default Message;