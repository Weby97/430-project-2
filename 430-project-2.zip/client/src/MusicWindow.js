import React from 'react';

class MusicWindow extends React.Component {
    render() {
        return (
            <main>
                <h1>Music Playlist!</h1>
                <h2>Here you can find what songs are on the current playlist for the app!</h2>
            </main>
        );
    }
    
}


export default MusicWindow;